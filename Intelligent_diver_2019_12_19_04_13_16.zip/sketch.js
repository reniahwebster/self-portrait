let angle = 0.0;
//let jitter = 0.0;

function setup() {

    var cnv = createCanvas(windowWidth, windowHeight);
    cnv.style('display', 'block');
}

function draw() {
    background(255,30,59);
    fill(255, 0, 0);
    ellipse(240, 240, 200, 200);
    fill(0,0,255);
    push();
    translate(240, 240);
    triangle(-10, 0, 10, 0, 0, -10);
    push();
    translate(0, -50);
    ellipse(40,15,10,10);
    ellipse(-40,15,10,10);
    rect(-30, 90, 60, 10);
    pop();
    pop();

    //console.log(mouseX);
}